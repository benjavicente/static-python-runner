import random
random.seed(2)

def decodificado_peachy(mensaje):
    if isinstance(mensaje, str): 
        if mensaje == "mapzirdj":
            return 1103
        elif mensaje == "qwftaaa":
            return 101101
        elif mensaje == "aeeeiiukkl":
            return 888888
        elif mensaje == "vaixkr":
            return 2022
        elif mensaje == "miaumiau":
            return 9999
        else:
            numero = [str(i) for i in range(len(mensaje)**2)]
            random.shuffle(numero)
            numero = "".join(numero[0:len(mensaje) + 2])
            return int(numero)
    else:
        return "La funcion no esta recibiendo un string, intenta nuevamente"

def decodificado_progra(numero):
    if isinstance(numero, int):
        if numero == 1103:
            return "Vas por excelente camino..."
        elif numero == 101101:
            return "El hechizero esta cerca..."
        elif numero == 888888:
            return "Intro intro intro!"
        elif numero == 2022:
            return "Oh no descubriste el secreto"
        elif numero == 9999:
            return "El hechizero te hara combatir.."
        else:
            abc = "abcdefghijklmnopkrstuvwxyz"
            string = [str(abc[i]) for i in range(0, min(len(str(numero)), 25))]
            random.shuffle(string)
            string = "".join(string[0: min(len(str(numero)), 10)])
            return string
    else:
        return "La funcion no esta recibiendo un entero, intenta nuevamente"